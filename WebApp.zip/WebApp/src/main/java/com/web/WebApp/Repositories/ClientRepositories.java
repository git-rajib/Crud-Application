package com.web.WebApp.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.web.WebApp.Model.Client; 


public interface ClientRepositories extends JpaRepository<Client,Integer> {
    
    public Client findByEmail(String email);
}
