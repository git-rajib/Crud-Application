package com.web.WebApp.Controller;

import ch.qos.logback.core.model.Model;
import com.web.WebApp.Repositories.ClientRepositories;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/clients")
public class ClientController {
    @Autowired
    private ClientRepositories clientRepo;

    @GetMapping({"","/"})
    public String listClients(Model model) {
        var clients = clientRepo.findAll(Sort.by(Sort.Direction.ASC, "id"));
        model.AddAttribute("clients", <clients>);

        return "clients/Clientlist"; // Assuming you have a Thymeleaf template at src/main/resources/templates/clients/list.html
    }

}
